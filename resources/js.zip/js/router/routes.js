import LoginComponent from '../components/auth/LoginComponent.vue'
import RegisterComponent from '../components/auth/RegisterComponent.vue'
import HomeComponent from '../components/home/HomeComponent.vue'

const routes = [
    {path: '',component:HomeComponent},
    {path: '/login',component:LoginComponent},
    {path: '/register',component:RegisterComponent},
]

export default routes



