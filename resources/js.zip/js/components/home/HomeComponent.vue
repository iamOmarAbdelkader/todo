<template>
    <div>
        <nav-component />   
<b-container fluid>
<div id="todo-list">
    <b-row>
    <b-col md="10" offset="1">
     
<b-card no-body class="overflow-hidden">
    <b-row no-gutters>
      <b-col md="4">
        <b-card-img src="./images/pic.jpg" class="side-img"></b-card-img>
      </b-col>
      <b-col md="8">
            <b-row>
                  <b-col md="12">
                       <b-button pill  @click="$bvModal.show(modals.create)" id="create-btn" variant="outline-primary">
                               <font-awesome-icon icon="plus" />
                       </b-button>
                  </b-col>
            </b-row>
        <b-card-body title="List">
          
          <b-card-text>
            <!-- Main table element -->
          
    <b-table
      :items="items"
      :fields="fields"
      :current-page="currentPage"
      :per-page="perPage"
    >
      <template slot="[name]" slot-scope="row">
        {{ row.value.first }} {{ row.value.last }}
      </template>

        <template slot="[actions]" >
             <b-button   size="sm" variant="outline-info" >
                               <font-awesome-icon icon="check" />
                </b-button>

                
                <b-button  size="sm"  variant="outline-success" >
                               <font-awesome-icon icon="edit" />
                </b-button>
                   <b-button size="sm" variant="outline-danger" >
                               <font-awesome-icon icon="trash-alt" />
                </b-button>
        </template>
    </b-table>
    
   <!-- <b-row>
           <b-col sm="7" md="12" class="my-1">
        <b-pagination
          v-model="currentPage"
          :total-rows="totalRows"
          :per-page="perPage"
          align="fill"
          size="sm"
          class="my-0"
        ></b-pagination>
      </b-col>
   </b-row> -->

          </b-card-text>
        </b-card-body>
      </b-col>
    </b-row>
  </b-card>
    </b-col>
</b-row>        
    </div>

    <!-- Info modal -->
     <b-modal size="lg" :id="modals.create"  modal-lg centered @ok="createTask" >
    <template slot="modal-title">
      Create A Task
    </template>
    <div class="d-block text-center">
       <b-form-textarea
      id="textarea"
      v-model="text"
      placeholder="Enter something..."
      rows="3"
      max-rows="6"
    ></b-form-textarea>
    </div>
  </b-modal>


  </b-container>
    </div>
</template>

<script>
   export default {
    data() {
      return {
        text: '',
        items: [
          {  name: { first: 'Geneva', last: 'Wilson' } },
          {  name: { first: 'Jami', last: 'Carney' } },
          {  name: { first: 'Essie', last: 'Dunlap' } },
          {  name: { first: 'Thor', last: 'Macdonald' } },
          { name: { first: 'Mitzi', last: 'Navarro' } },
        ],
        fields: [
          { key: 'name', label: 'Person Full name' },
          { key: 'actions', label: 'Actions' }
        ],
        totalRows: 1,
        currentPage: 1,
        perPage: 4,
       modals:{
        info:'info-modal',
          create:'create-modal',
         edit:'edit-modal',
         del:'delete-modal',
         done:'done-modal',
      }
      }
    },
    mounted() {
      // Set the initial number of items
      this.totalRows = this.items.length
    },
    methods: {
      info(item, index, button) {
          this.$bvModal.show(this.modals.info)	
      },
      createTask(){
          console.log('hello ok clicked')
      }
    }
  }
</script>
<style scoped>
#todo-list{
    margin-top: 20px;
}
#create-btn{
    float: right;
    margin:15px 10px;
}
#create-btn::after{
    content: '';
    clear: both;
}
.side-img{
    height: 100%;
}
</style>
