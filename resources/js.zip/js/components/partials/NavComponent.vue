<template>
    <div>
  <b-navbar toggleable="lg" type="dark" variant="info">
    <router-link style="cursor:pointer" tag="b-navbar-brand" to="/">ToDo</router-link>

    <b-navbar-toggle target="nav-collapse"></b-navbar-toggle>

    <b-collapse id="nav-collapse" is-nav>
      <b-navbar-nav>
        <!-- <b-nav-item href="#">Link</b-nav-item> -->
      </b-navbar-nav>

      <!-- Right aligned nav items -->
      <b-navbar-nav class="ml-auto">
        <router-link active-class="active"  tag="b-nav-item" to="login">Login</router-link>
        <router-link active-class="active" tag="b-nav-item" to="register">Register</router-link>
      </b-navbar-nav>
    </b-collapse>
  </b-navbar>
</div>
</template>

<script>
    export default {
     
    }
</script>
