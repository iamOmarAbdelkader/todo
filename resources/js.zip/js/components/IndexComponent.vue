<template>
    <div>
       <router-view></router-view>
    </div>
</template>

<script>
    export default {
        mounted(){
        // axios.post('auth/login',{
        //     email:'admin@admin.com',
        //     password:'123456'
        // }).then((res)=>{
        //     this.$auth.setToken(res.data.access_token , res.data.expires_in)
        // })


        //  this.$auth.login({
        //             // body: this.data.body, // Vue-resource
        //             data: {
        //                 email:'admin@admin.com',
        //                 password:'123456'
        //             },
        //             rememberMe: true,
        //             redirect: null,
        //             fetchUser: true
        //         })
        //         .then(() => {
        //             console.log('success ' + this.context);
        //         }, (res) => {
        //             console.log('error ' + this.context);
        //             this.error = res.data;
        //         });
    }
}
</script>
  