require('./bootstrap');
window.Vue = require('vue');
const files = require.context('./', true, /\.vue$/i)
files.keys().map(key => Vue.component(key.split('/').pop().split('.')[0], files(key).default))


require('./font-awesome')
import BootstrapVue from 'bootstrap-vue'
import auth from './packages/auth/auth.js'
import router from './router/index'

Vue.use(auth);
Vue.use(BootstrapVue)

// axios.defaults.headers.common['Authorization'] = 'Bearer '+ Vue.auth.getToken();

const app = new Vue({
    el: '#app',
    router
});
